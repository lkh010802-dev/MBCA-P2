# Backend CSV Schema v1.0

파일명:

```text
output/YYYYMMDD_popup.csv
```

인코딩: UTF-8 BOM (`utf-8-sig`)

| 컬럼 | 의미 | 형식/비고 |
|---|---|---|
| popup_id | 영구 팝업 식별자 | 문자열, backend upsert key 권장 |
| name | canonical 팝업명 | 문자열 |
| brand | 브랜드 | nullable |
| category | 대표 카테고리 | nullable |
| categories | 복수 카테고리 | JSON array 문자열 |
| start_date | 시작일 | YYYY-MM-DD |
| end_date | 종료일 | YYYY-MM-DD, nullable |
| status | 현재 상태 | ACTIVE / UPCOMING |
| venue_name | 장소명 | nullable |
| address | 상세 주소 | nullable |
| address_base | 정규화 기본 주소 | nullable |
| district | 서울 자치구 | nullable |
| latitude | 위도 | decimal, nullable |
| longitude | 경도 | decimal, nullable |
| description | 통합 설명 | nullable |
| reservation_required | 예약 필요 여부 | true/false/빈값 |
| reservation_url | 예약 URL | nullable |
| official_url | 공식 URL | nullable |
| detail_url | 대표 상세 URL | nullable |
| image_url | 대표 이미지 URL | nullable |
| tags | 태그 | JSON array 문자열 |
| operation_hours | 운영시간 | JSON array 문자열 |
| benefits | 혜택/특전 | JSON 문자열 또는 빈값 |
| website_links | 웹 링크 | JSON object 문자열 |
| sources | 현재 확인 source | `|` 구분 문자열 |
| source_count | 현재 source 수 | integer |
| source_refs | source별 ID/URL provenance | JSON array 문자열 |
| confidence | canonical 신뢰도 | decimal |
| first_seen_at | 최초 관측 시각 | ISO 8601 +09:00 |
| last_seen_at | 마지막 관측 시각 | ISO 8601 +09:00 |
| last_verified_at | 마지막 검증 시각 | ISO 8601 +09:00 |

## 주의

1. JSON 형태 컬럼은 단순 쉼표 split을 하지 말고 표준 CSV parser로 먼저 cell을 읽은 뒤 JSON parse해야 합니다.
2. `end_date`가 비어 있을 수 있으므로 DB NOT NULL을 강제하지 마십시오.
3. `popup_id`는 crawler master가 유지하는 식별자입니다. name/address만으로 backend에서 새 ID를 다시 만들지 않는 것을 권장합니다.
4. 현재 CSV는 current snapshot이므로 ENDED/UNVERIFIED는 포함하지 않습니다.
