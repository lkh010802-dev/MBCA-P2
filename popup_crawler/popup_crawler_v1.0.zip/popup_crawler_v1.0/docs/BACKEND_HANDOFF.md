# 백엔드 인수인계 가이드

## 1. 백엔드가 소비할 파일

정상 일일 실행 후:

```text
output/YYYYMMDD_popup.csv
```

이 파일은 해당 날짜 기준 **검증된 ACTIVE + UPCOMING 팝업의 전체 snapshot**입니다.

예:

```text
output/20260901_popup.csv
```

BLOCKED/FAILED 실행에서는 새 CSV를 정상 산출물로 갱신하지 않습니다. 따라서 백엔드는 `output/`의 성공 산출물만 소비하는 것을 권장합니다.

## 2. 핵심 식별자

`popup_id`를 backend upsert key로 권장합니다.

형식 예:

```text
popup_91439c147f15f133
```

동일 팝업은 다음 일일 실행에서도 기존 `popup_id`를 재사용하도록 master에서 관리합니다.

> 운영 환경을 이전할 때 기존 `popup_id`, first_seen, 이력의 연속성을 유지하려면 `data/master/`를 반드시 함께 이관하십시오.

## 3. CSV 의미

- snapshot 파일이며 delta 파일이 아님
- ACTIVE + UPCOMING만 포함
- ENDED/UNVERIFIED는 CSV에서 제외되며 내부 master에 남음
- `end_date` 등 일부 필드는 nullable
- `categories`, `tags`, `operation_hours`, `benefits`, `website_links`, `source_refs`는 CSV cell 안의 JSON 문자열
- `sources`는 `dayforyou|popga|popply`처럼 `|` 구분 문자열
- 인코딩은 UTF-8 BOM (`utf-8-sig`), newline-safe CSV quoting

## 4. 기존 장소 DB와 매핑할 때

아직 기존 장소 테이블의 컬럼명/정규화 규칙이 확정되지 않았으므로 v1.0에서는 crawler canonical을 유지합니다.

권장 방식:

```text
crawler canonical/master
        ↓
storage/csv_export.py
        ↓
backend-specific mapping
        ↓
기존 장소 DB import/upsert
```

즉 crawler/parser/master를 backend DB schema에 직접 결합하지 않고 exporter에서만 매핑하십시오.

## 5. 권장 ingest 전략

현재 팝업 테이블이 별도라면:

1. 파일 생성 완료를 확인
2. 임시 staging table에 CSV load
3. `popup_id` 중복/필수 컬럼 검증
4. transaction 내 upsert
5. snapshot 기준 current 상태 반영
6. staging 폐기

기존 장소 테이블과 통합할 예정이라면 latitude/longitude 또는 주소 기반 장소 매칭 정책이 확정되기 전에는 `venue_name`만으로 장소를 자동 통합하지 않는 것을 권장합니다.

## 6. 성공/실패 신호

일일 application report:

```text
data/daily/latest_report.json
```

성공:

```json
{"status":"SUCCESS"}
```

품질 차단 예:

```text
BLOCKED_SOURCE_QUALITY
BLOCKED_INTEGRATION
BLOCKED_SOURCE_STAGE
FAILED
```

백엔드 ingest job을 crawler와 연동할 경우 `status == SUCCESS`이면서 해당 날짜 `output/YYYYMMDD_popup.csv`가 존재할 때만 import하십시오.

## 7. 데이터 보존

백엔드 전달 파일은 `output/`만으로 충분하지만 crawler 운영 서버에서는 아래를 persistent volume으로 보존하는 것을 권장합니다.

```text
data/master/      필수: ID/이력 연속성
output/           필수: backend snapshot
logs/             권장
```

속도 최적화를 위해 아래도 보존 권장:

```text
data/popga/runs/
data/popply/runs/
```

과거 정상 상세 캐시를 재사용할 수 있습니다.

## 8. 외부 재배포 주의

본 프로그램은 공개 페이지를 저빈도로 수집하는 내부 데이터 파이프라인입니다. 각 원천 사이트의 콘텐츠를 외부에 원문 그대로 재배포하는 권리를 본 코드가 부여하지 않습니다. 백엔드 서비스 공개 범위/표시 정책은 별도 약관 및 권리 검토가 필요합니다.
