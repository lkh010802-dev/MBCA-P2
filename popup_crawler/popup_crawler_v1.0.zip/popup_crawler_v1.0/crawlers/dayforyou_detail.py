from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

try:
    import truststore
    truststore.inject_into_ssl()
except ImportError:
    pass


SITE_URL = "https://dayforyou.com"
FALLBACK_SITE_URL = "https://www.dayforyou.com"
DETAIL_URL = SITE_URL + "/getDetail?scheduleSeq={source_id}"
DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}")


@dataclass
class DetailRecord:
    source: str
    source_id: str
    detail_url: str
    title_detail: str | None
    start_date_detail: str | None
    end_date_detail: str | None
    address_detail: str | None
    hashtags: list[str]
    tip_text: str | None
    summary_text: str | None
    official_url: str | None
    fetch_ok: bool
    http_status: int | None
    parse_warnings: list[str]
    fetched_from_cache: bool


def _clean_text(value: str | None) -> str:
    return re.sub(r"\s+", " ", value or "").strip()


def _text_of(soup: BeautifulSoup, selector: str) -> str | None:
    node = soup.select_one(selector)
    if not node:
        return None
    value = _clean_text(node.get_text(" ", strip=True))
    return value or None


def _extract_title(soup: BeautifulSoup) -> str | None:
    value = _text_of(soup, "#schedule_title")
    if value:
        return value

    if soup.title:
        value = _clean_text(soup.title.get_text(" ", strip=True))
        value = re.sub(r"\s*-\s*데이포유\s*$", "", value).strip()
        return value or None

    return None


def _extract_period(soup: BeautifulSoup) -> tuple[str | None, str | None]:
    value = _text_of(soup, ".schedule_date")
    if not value:
        return None, None

    dates = DATE_RE.findall(value)
    if len(dates) >= 2:
        return dates[0], dates[1]
    return None, None


def _extract_address(soup: BeautifulSoup) -> str | None:
    """
    실제 DOM:
      <div id="schedule_location">
        서울 ...
        <button onclick="copyLocation('서울 ...')">복사</button>
        ...
      </div>

    v0.3은 copyLocation(event,'주소')만 가정해서 64건 모두 address_missing이 났다.
    v0.3.1은 #schedule_location 자체를 직접 읽는다.
    """
    node = soup.select_one("#schedule_location")
    if not node:
        return None

    fragment = BeautifulSoup(str(node), "html.parser")

    for tag in fragment.select("button, a, i, img"):
        tag.decompose()

    value = _clean_text(fragment.get_text(" ", strip=True))
    value = re.sub(r"\s*복사\s*$", "", value).strip()

    if value:
        return value

    # fallback: onclick의 copyLocation('주소')
    button = node.select_one("button.copy_loc_btn")
    if button:
        onclick = button.get("onclick", "") or ""
        match = re.search(
            r"copyLocation\s*\(\s*['\"](?P<loc>.*?)['\"]\s*\)",
            onclick,
            flags=re.S,
        )
        if match:
            return _clean_text(match.group("loc"))

    return None


def _extract_hashtags(soup: BeautifulSoup) -> list[str]:
    container = soup.select_one(".hashtag-container")
    if not container:
        return []

    tags = []
    seen = set()

    # 실제 HTML에는 .hashtag 요소들이 존재.
    nodes = container.select(".hashtag")
    if nodes:
        values = [_clean_text(n.get_text(" ", strip=True)) for n in nodes]
    else:
        values = re.findall(
            r"#[0-9A-Za-z가-힣_]+",
            container.get_text(" ", strip=True),
        )

    for value in values:
        if not value:
            continue
        if not value.startswith("#"):
            value = "#" + value.lstrip("#")
        if value not in seen:
            seen.add(value)
            tags.append(value)

    return tags


def _extract_summary(soup: BeautifulSoup) -> str | None:
    return _text_of(soup, "#schedule_comment")


def _extract_tip(soup: BeautifulSoup) -> str | None:
    return _text_of(soup, ".schedule_detail")


def _extract_official_url(soup: BeautifulSoup) -> str | None:
    node = soup.select_one("#schedule_homepage")
    if not node:
        return None

    href = (node.get("href") or "").strip()
    if not href:
        return None

    return urljoin(SITE_URL, href)


def parse_detail_html(
    html: str,
    source_id: str,
    detail_url: str,
    *,
    http_status: int | None = 200,
    fetched_from_cache: bool = False,
) -> DetailRecord:
    soup = BeautifulSoup(html, "html.parser")
    warnings: list[str] = []

    title = _extract_title(soup)
    start_date, end_date = _extract_period(soup)
    address = _extract_address(soup)
    hashtags = _extract_hashtags(soup)
    summary = _extract_summary(soup)
    tip = _extract_tip(soup)
    official_url = _extract_official_url(soup)

    if not title:
        warnings.append("title_missing")
    if not start_date or not end_date:
        warnings.append("period_missing")
    if not address:
        warnings.append("address_missing")
    if not hashtags:
        warnings.append("hashtags_missing")
    if not summary and not tip:
        warnings.append("detail_text_sparse")

    return DetailRecord(
        source="dayforyou",
        source_id=str(source_id),
        detail_url=detail_url,
        title_detail=title,
        start_date_detail=start_date,
        end_date_detail=end_date,
        address_detail=address,
        hashtags=hashtags,
        tip_text=tip,
        summary_text=summary,
        official_url=official_url,
        fetch_ok=True,
        http_status=http_status,
        parse_warnings=warnings,
        fetched_from_cache=fetched_from_cache,
    )


def _failed_record(
    source_id: str,
    detail_url: str,
    status: int | None,
    warning: str,
) -> DetailRecord:
    return DetailRecord(
        source="dayforyou",
        source_id=str(source_id),
        detail_url=detail_url,
        title_detail=None,
        start_date_detail=None,
        end_date_detail=None,
        address_detail=None,
        hashtags=[],
        tip_text=None,
        summary_text=None,
        official_url=None,
        fetch_ok=False,
        http_status=status,
        parse_warnings=[warning],
        fetched_from_cache=False,
    )


def _detail_url_candidates(detail_url: str, source_id: str) -> list[str]:
    candidates = [detail_url]
    if "www.dayforyou.com" in detail_url:
        candidates.append(detail_url.replace("https://www.dayforyou.com", SITE_URL, 1))
    elif "dayforyou.com" in detail_url:
        candidates.append(detail_url.replace("https://dayforyou.com", FALLBACK_SITE_URL, 1))
    else:
        candidates.extend([
            DETAIL_URL.format(source_id=source_id),
            FALLBACK_SITE_URL + f"/getDetail?scheduleSeq={source_id}",
        ])
    return list(dict.fromkeys(candidates))


def fetch_details(
    review_items: list[dict],
    cache_dir: str | Path = "data/detail_html",
    *,
    delay_seconds: float | None = None,
    timeout: int = 20,
    retries: int = 2,
) -> list[DetailRecord]:
    cache_dir = Path(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)

    if delay_seconds is None:
        delay_seconds = float(os.getenv("DETAIL_REQUEST_DELAY", "0.5"))

    session = requests.Session()
    session.headers.update({
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/151.0 Safari/537.36"
        ),
        "Accept-Language": "ko-KR,ko;q=0.9,en;q=0.8",
        "Referer": SITE_URL + "/getScheduleList",
    })

    results: list[DetailRecord] = []
    total = len(review_items)

    for index, item in enumerate(review_items, start=1):
        source_id = str(item["source_id"])
        detail_url = item.get("detail_url") or DETAIL_URL.format(source_id=source_id)
        cache_path = cache_dir / f"{source_id}.html"

        print(f"    [DETAIL {index}/{total}] {source_id}", end="")

        if cache_path.exists() and cache_path.stat().st_size > 200:
            html = cache_path.read_text(encoding="utf-8", errors="replace")
            results.append(
                parse_detail_html(
                    html,
                    source_id,
                    detail_url,
                    fetched_from_cache=True,
                )
            )
            print(" - cache/reparsed")
            continue

        last_error = None
        last_status = None

        success = False
        candidates = _detail_url_candidates(detail_url, source_id)
        for attempt in range(1, retries + 1):
            for candidate_url in candidates:
                try:
                    response = session.get(candidate_url, timeout=timeout)
                    last_status = response.status_code

                    if response.status_code == 200:
                        html = response.content.decode("utf-8", errors="replace")
                        cache_path.write_text(html, encoding="utf-8")
                        results.append(
                            parse_detail_html(
                                html,
                                source_id,
                                response.url or candidate_url,
                                http_status=response.status_code,
                            )
                        )
                        print(" - ok")
                        last_error = None
                        success = True
                        break

                    last_error = f"http_{response.status_code}"
                except requests.RequestException as exc:
                    last_error = exc.__class__.__name__
            if success:
                break
            if attempt < retries:
                time.sleep(1.0 * attempt)

        if last_error:
            results.append(
                _failed_record(source_id, detail_url, last_status, last_error)
            )
            print(f" - fail ({last_error})")

        time.sleep(max(0.0, delay_seconds))

    return results


def save_detail_jsonl(
    records: Iterable[DetailRecord],
    path: str | Path,
) -> int:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    count = 0
    with path.open("w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(asdict(record), ensure_ascii=False) + "\n")
            count += 1
    return count
