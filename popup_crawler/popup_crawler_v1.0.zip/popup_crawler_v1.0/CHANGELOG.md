# Changelog

## 1.0.0 - 2026-09-01

- First internal operations/backend handoff release.
- Freeze v0.9.7 classification/duplicate review resolution baseline.
- Added Windows daily scheduler setup/remove/status scripts.
- Added unattended scheduled runner and scheduler logs.
- Standardized top-level version labels to 1.0.0.
- Added backend handoff, CSV schema, install/schedule, and operations runbook docs.
- Runtime data/output/logs excluded from source-control defaults.
